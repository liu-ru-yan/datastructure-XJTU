#include<bits/stdc++.h>
#include <sched.h>
using namespace std;
int fflag;
class Course{
public:
    string id;
    double credit;
    vector<string> precourse;
    Course* next;
};
class Schedule{
public:
    vector<string> coursein;
    double credits;
};

string find_max_credits(set<string> course_available,map<string,double> course_and_credits){
    int max=-1;
    string key="";
    for(auto iterator=course_available.begin();iterator!=course_available.end();iterator++){
        if(max<course_and_credits[*iterator]){
            max=course_and_credits[*iterator];
            key=*iterator;
        }
    }
    return key;
}

void hello(){
    cout<<"Here is the input format prompt."<<endl;
    cout<<"First, you need to input the number of semesters and the maximum number of credits per semester. After that, you will input all the courses."<<endl;
    cout<<"The input format for courses is:"<<endl;
    cout<<"Enter the course number (a three-character string), the course credits, and all the prerequisite courses for that course. After entering all the prerequisite courses, type 'end' to finish inputting the current course."<<endl;
    cout<<"At this point, you can choose to continue entering courses, using the same format as before."<<endl;
    cout<<"If you have finished entering all courses, type 'end' to conclude the course input process."<<endl;
    cout<<"If the course number is entered incorrectly, you can enter -1 when entering the credits (this will allow you to go back to the course number input), and then continue to re-enter the course information on the same line."<<endl;
    cout<<"If the prerequisite courses are entered incorrectly, you can enter 'wrg', and then re-enter all the prerequisite courses."<<endl;
    cout<<"If you notice that the course number for the prerequisite course was entered incorrectly during the input process, you can enter 'wrc', and then re-enter all the information for this course."<<endl;
}
tuple<Course*,int,int> init(){
    int semesters,limit;
    Course* head; 
    head=new Course();
    head->next=NULL;
    Course* temp=head;
    cout<<"Enter the total number of semesters:";
    cin>>semesters;
    
    cout<<"Enter the maximum number of credits per semester:";
    cin>>limit;
    while(1){
    get1:
        string s;
        cout<<"Enter course information:";
        cin>>s;
        //cout<<s;
        if(s.length()!=3){
            cout<<"The course number is an illegal input, please re-enter the course information."<<endl;
            goto get1;
        }
        if(s=="end"){
            break;
        }
        else{
            Course* a=new Course();
            a->next=NULL;
            a->id=s;
            cout<<"Credits:";
            cin>>a->credit;
            if(a->credit==-1){
                delete a;
                goto get1;
            }
            while(1){
            get2:
                cout<<"Prerequisite Courses:";
                string ss;
                cin>>ss;
                if(ss.length()!=3){
                    cout<<"The course number is an illegal input, please re-enter the course number."<<endl;
                    goto get2;
                }
                if(ss=="wrg"){
                    a->precourse.clear();
                    cout<<"The prerequisite courses previously entered have all been cleared."<<endl;
                    goto get2;
                }
                if(ss=="wrc"){
                    delete a;
                    goto get1;
                }
                if(ss=="end"){
                    break;
                }
                else{
                    a->precourse.push_back(ss);
                }
            }
            temp->next=a;
            temp=temp->next;
        }
    }
    return {head,semesters,limit};
}

map<string,set<string>> build_prerequiest(Course* head){
    Course* temp;
    temp=head->next;
    while(temp!=NULL){
        //cout<<temp->precourse.empty();
        if(temp->precourse.empty()==1){
            temp->precourse.push_back("nan");
        }
        temp=temp->next;
    }
    //for(auto iterator=)
    //处理vector->set
    //cout<<"?";
    map<string,set<string>> prerequiest;
    temp=head->next;
    while(temp!=NULL){
        set<string> tem;
        for(auto iterator=temp->precourse.begin();iterator!=temp->precourse.end();iterator++){
            if(*iterator=="nan"){
                //cout<<"@@"<<temp->id;
                break;
            }
            tem.insert(*iterator);
        }
        prerequiest[temp->id]=tem;
        
        for(auto iterator1=temp->precourse.begin();iterator1!=temp->precourse.end();iterator1++){
            for(auto iterator2=prerequiest[*iterator1].begin();iterator2!=prerequiest[*iterator1].end();iterator2++){
                if(prerequiest[temp->id].find(*iterator2)==prerequiest[temp->id].end()){
                    prerequiest[temp->id].insert(*iterator2);
                }
            }
        }
        temp=temp->next;
    }
    return prerequiest;
}

tuple<map<string,int>> build_valid_and_influence(Course* head,map<string,set<string>>& prerequiest){
    map<string,int> valid;
    map<string,set<string>> influence;
    auto temp=head->next;
    while(temp!=NULL){
        valid.insert({temp->id,0});
        Course* temp1=head->next;
        int flag=0;//flag=0，则说明temp没有影响之后的课程；
        while(temp1!=NULL){
            if(temp1==temp){
                temp1=temp1->next;
                continue;
            }
            else{
                if(prerequiest[temp1->id].find(temp->id)==prerequiest[temp1->id].end()){
                    temp1=temp1->next;
                    continue;
                }
                else{
                    flag=1;
                    influence[temp->id].insert(temp1->id);
                    temp1=temp1->next;
                    continue;
                }
            }
        }
        if(flag==0){
            valid[temp->id]=1;
        }
        temp=temp->next;
    }
    temp=head->next;
    while(temp!=NULL){

        temp=temp->next;
    }

    temp=head->next;
    while(temp!=NULL){
        if(prerequiest[temp->id].empty()==1){
            valid[temp->id]=-1;
        }
        temp=temp->next;
    }
    return valid;
}
tuple<Schedule*,map<string,double>,set<string>> schedule_mode1(Course* head,int limit,int semesters,map<string,int>& valid_ref,map<string,set<string>>& prerequiest,Schedule schedule[]){
    set<string> ordered;
    map<string,double> course_and_credits;
    map<string,int> valid=valid_ref;
    auto temp=head->next;
    while(temp!=NULL){
        course_and_credits[temp->id]=temp->credit;
        temp=temp->next;
    }

    for(int semes=0;semes<semesters;semes++){
        schedule[semes].credits=0;
        schedule[semes].coursein.clear();
    }
    for(int semes=0;semes<semesters;semes++){
        set<string> course_available;
        for(auto iterator=valid.begin();iterator!=valid.end();iterator++){
            if(iterator->second==-1){
                course_available.insert(iterator->first);
            }
        }
        while(1){
            if(course_available.empty()==1){
                break;
            }
            auto key_max=find_max_credits(course_available,course_and_credits);
            if(schedule[semes].credits+course_and_credits[key_max]>limit-1){
                course_available.erase(key_max);
                continue;
            }
            else{
                schedule[semes].credits+=course_and_credits[key_max];
                schedule[semes].coursein.push_back(key_max);
                course_available.erase(key_max);
                ordered.insert(key_max);
                continue;
            }
        }
        temp=head->next;
        while(temp!=NULL){
            if(ordered.find(temp->id)!=ordered.end()){
                valid[temp->id]=-2;
                temp=temp->next;
                continue;
            }
            else{
                int flag=0;
                for(auto iterator=prerequiest[temp->id].begin();iterator!=prerequiest[temp->id].end();iterator++){
                    if(ordered.find(*iterator)==ordered.end()){
                        flag=1;
                    }
                }
                if(flag==0){
                    valid[temp->id]=-1;
                }
                temp=temp->next;
            }
        }
    }      
    Schedule* p=&schedule[0];  
    return {p,course_and_credits,ordered};
}
tuple<Schedule*,map<string,double>,set<string>> schedule_mode2(Course* head,int limit,int semesters,map<string,int>& valid,map<string,set<string>>& prerequiest,Schedule schedule[]){
    set<string> ordered;
    map<string,double> course_and_credits;
    auto temp=head->next;
    while(temp!=NULL){
        course_and_credits[temp->id]=temp->credit;
        temp=temp->next;
    }
    

    for(int semes=0;semes<semesters;semes++){
        schedule[semes].credits=0;
        schedule[semes].coursein.clear();
    }
    for(int semes=0;semes<semesters;semes++){
        set<string> course_available;
        for(auto iterator=valid.begin();iterator!=valid.end();iterator++){
            if(iterator->second==-1){
                course_available.insert(iterator->first);
            }
        }
        while(1){
            if(course_available.empty()==1){
                break;
            }
            auto key_max=find_max_credits(course_available,course_and_credits);
            if(schedule[semes].credits+course_and_credits[key_max]>limit){
                course_available.erase(key_max);
                continue;
                
            }
            else{
                schedule[semes].credits+=course_and_credits[key_max];
                schedule[semes].coursein.push_back(key_max);
                course_available.erase(key_max);
                ordered.insert(key_max);
                continue;
            }

        }
        temp=head->next;
        while(temp!=NULL){
            if(ordered.find(temp->id)!=ordered.end()){
                valid[temp->id]=-2;
                temp=temp->next;
                continue;
            }
            else{
                int flag=0;
                for(auto iterator=prerequiest[temp->id].begin();iterator!=prerequiest[temp->id].end();iterator++){
                    if(ordered.find(*iterator)==ordered.end()){
                        flag=1;
                    }
                }
                if(flag==0){
                    valid[temp->id]=-1;
                }
                temp=temp->next;
            }
        }
    }
    Schedule* p=&schedule[0];

    return {p,course_and_credits,ordered};
}
tuple<int,Schedule*,map<string,double>> choice(Course* head,int limit,int semesters,map<string,int>& valid,map<string,set<string>>& prerequiest,Schedule schedule[]){
get3:
    int mode;
    cout<<endl;
    cout<<"Please select the scheduling strategy:"<<endl;
    cout<<"1. Distribute the workload evenly across all semesters."<<endl;
    cout<<"2. Concentrate the courses as much as possible in the first few semesters."<<endl;
    cin>>mode;
    int flag=0;
    Schedule* p;
    map<string,double> course_and_credits;
    if(mode==1||mode==2){
        if(mode==1){
            int c=limit;
            int flag_no=0;
            while(1){
                auto [p,course_and_credits,ordered]=schedule_mode1(head,c,semesters,valid,prerequiest,schedule);
                auto temp=head->next;
                while(temp!=NULL){
                    if(ordered.find(temp->id)==ordered.end()){
                        flag=1;
                    }
                    temp=temp->next;
                }

                if(c==limit&&flag==1){
                    flag_no=1;
                    break;
                }
                if(flag==0){
                    c--;
                }
                else{
                    break;
                }
            }
            flag=0;
            if(flag_no==1){
                flag=1;
            }
            if(flag_no==0){
                c=c+1;
            }
            //cout<<flag_no;
            auto [p,course_and_credits,ordered]=schedule_mode1(head,c,semesters,valid,prerequiest,schedule);
        }
        else{
            auto [p,course_and_credits,ordered]=schedule_mode2(head,limit,semesters,valid,prerequiest,schedule);
            auto temp=head->next;
            while(temp!=NULL){
                if(ordered.find(temp->id)==ordered.end()){
                    flag=1;
                }
                temp=temp->next;
            }   
        }
    }
    else{
        cout<<"Illegal input, please reselect the scheduling strategy."<<endl;
        goto get3;
    }
    //cout<<flag;
    

    /*
    int flag=0;
    auto temp=head->next;
    while(temp!=NULL){
        if(ordered.find(temp->id)==ordered.end()){
            flag=1;
            break;
        }
        temp=temp->next;
    }*/





    //cout<<flag;

    map<string,double> ce;
    auto tempp=head->next;
    while(tempp!=NULL){
        ce[tempp->id]=tempp->credit;
        tempp=tempp->next;
    }
    if(flag==0){
        for(int semes=0;semes<semesters;semes++){
            cout<<"------------"<<"semester"<<' '<<semes+1<<"------------"<<endl;
            cout<<"course"<<"      "<<"credits"<<endl;
            for(auto iterator=schedule[semes].coursein.begin();iterator!=schedule[semes].coursein.end();iterator++){
                cout<<"  "<<*iterator<<"           "<<ce[*iterator]<<endl;
            }
            cout<<"total credits:"<<schedule[semes].credits<<endl;
        }
    }
    else{
        cout<<"Under these conditions, it is not possible to complete the course scheduling."<<endl;
    }
    return {flag,p,ce};
}
int main(){
    hello();
    Course* temp;
    auto [head,semesters,limit]=init();
    auto prerequiest=build_prerequiest(head);
    temp=head->next;
    auto[valid]=build_valid_and_influence(head,prerequiest);
    Schedule schedule[semesters];
    auto[flag,p,course_and_credits]=choice(head,limit,semesters,valid,prerequiest,schedule);
    return 0;
}

