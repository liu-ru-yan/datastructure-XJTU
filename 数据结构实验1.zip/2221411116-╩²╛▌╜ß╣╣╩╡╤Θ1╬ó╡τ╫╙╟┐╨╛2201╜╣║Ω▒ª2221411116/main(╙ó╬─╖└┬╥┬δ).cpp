#include<bits/stdc++.h>

void hello_calculator(){
    std::cout<<"This is a univariate sparse polynomial calculator."<<std::endl;
    std::cout<<"Below are the instructions."<<std::endl;
    std::cout<<"When entering the polynomial, input it in the following format:"<<std::endl;
    std::cout<<std::endl;
    std::cout<<"When entering the polynomial, first input the number of terms, and then enter the coefficients and exponents of each term in descending order of exponents. Entering two consecutive negative numbers will end the input."<<std::endl;
    std::cout<<std::endl;
    std::cout<<"Select the calculation method, where '1' represents addition operation, and '2' represents subtraction operation."<<std::endl;
    std::cout<<std::endl;
    std::cout<<"Confirm whether to calculate the value of the polynomial at x [yes/no]."<<std::endl;
    std::cout<<std::endl;
    std::cout<<"If you wish to calculate the value of the polynomial at x, please enter the value of x."<<std::endl;

}
/*
class Poly_member;
Poly_member* Poly_plus(Poly_member* h1,Poly_member* h2);
*/
class Poly_member{
private:
    double exponent;
    double coefficient;
    Poly_member* next;
public:
    friend Poly_member* Poly_plus(Poly_member* h1,Poly_member* h2);
    friend Poly_member* Poly_subtraction(Poly_member* h1,Poly_member* h2);
    friend Poly_member* init_Poly_member();
    friend double calculate_Poly(Poly_member* h1,double x);
    friend void show_Poly(Poly_member* he);     
};

void show_Poly(Poly_member* he){
    Poly_member* temp=he->next;
        int flag=1;
        while(1){
            if(temp==NULL){
                break;
            }
            if(temp->coefficient==0){
                temp=temp->next;
                continue;
            }
            if(flag==1){
                flag=0;
            }
            else{
                std::cout<<"+";
            }
            
            if(temp->coefficient>=0){
                std::cout<<temp->coefficient<<"x^"<<temp->exponent;
            }
            else{
                std::cout<<"("<<temp->coefficient<<"x^"<<temp->exponent<<")";
            }
            temp=temp->next;
        }
        if(flag==1){
            std::cout<<"0"<<std::endl;
        }
}



Poly_member* Poly_plus(Poly_member* h1,Poly_member* h2){
    Poly_member* t1=h1->next;
    Poly_member* t2=h2->next;
    Poly_member* sum=new Poly_member();
    sum->next=NULL;
    Poly_member* temp=sum;
    while(1){
        if(t1==NULL&&t2==NULL){
            break;
        }
        if(t1!=NULL&&t2!=NULL){
            if(t1->exponent>t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t1->exponent;
                a->coefficient=t1->coefficient;
                temp->next=a;
                temp=temp->next;
                t1=t1->next;
                continue;
            }
            if(t1->exponent<t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t2->exponent;
                a->coefficient=t2->coefficient;
                temp->next=a;
                temp=temp->next;
                t2=t2->next;
                continue;
            }
            if(t1->exponent==t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t1->exponent;
                a->coefficient=t1->coefficient+t2->coefficient;
                temp->next=a;
                temp=temp->next;
                t1=t1->next;
                t2=t2->next;
                continue;
            }
        }
        if(t1==NULL&&t2!=NULL){
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=t2->exponent;
            a->coefficient=t2->coefficient;
            temp->next=a;
            temp=temp->next;
            t2=t2->next;
            continue;
        }
        if(t1!=NULL&&t2==NULL){
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=t1->exponent;
            a->coefficient=t1->coefficient;
            temp->next=a;
            temp=temp->next;
            t1=t1->next;
            continue;
        } 
        
        
    }
    return sum;
}
Poly_member* Poly_subtraction(Poly_member* h1,Poly_member* h2){
    Poly_member* t1=h1;
    Poly_member* t2=h2;
    Poly_member* ans=new Poly_member();
    ans->next=NULL;
    Poly_member* temp=ans;
    while(1){
        if(t1==NULL&&t2==NULL){
            break;
        }
        if(t1!=NULL&&t2!=NULL){
            if(t1->exponent>t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t1->exponent;
                a->coefficient=t1->coefficient;
                temp->next=a;
                temp=temp->next;
                t1=t1->next;
                continue;

            }
            if(t1->exponent<t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t2->exponent;
                a->coefficient=-t2->coefficient;
                temp->next=a;
                temp=temp->next;
                t2=t2->next;
                continue;
            }
            if(t1->exponent==t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t1->exponent;
                a->coefficient=t1->coefficient-t2->coefficient;
                temp->next=a;
                temp=temp->next;
                t1=t1->next;
                t2=t2->next;
                continue;
            }
        }
        if(t1==NULL&&t2!=NULL){
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=t2->exponent;
            a->coefficient=-t2->coefficient;
            temp->next=a;
            temp=temp->next;
            t2=t2->next;
            continue;
        }
        if(t1!=NULL&&t2==NULL){
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=t1->exponent;
            a->coefficient=t1->coefficient;
            temp->next=a;
            temp=temp->next;
            t1=t1->next;
            continue;
        }
    }
    return ans->next;
}








Poly_member* init_Poly_member(){
        Poly_member* head=new Poly_member();
        head->next=NULL;
        Poly_member* temp=head;
        int n;std::cin>>n;
        int i=0;
        while(i<n){
            double exp,coe;std::cin>>coe>>exp;
            if(coe<0&&exp<0){
                break;
            }
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=exp;
            a->coefficient=coe;
            temp->next=a;
            temp=temp->next;
            i++;
        }
        return head;
}

double calculate_Poly(Poly_member* h1,double x){
    double ans=0.0;
    Poly_member* temp=h1->next;
    while(1){
        if(temp==NULL){
            break;
        }
        else{
            ans=ans+(temp->coefficient*pow(x,temp->exponent));
            temp=temp->next;
        }
    }
    return ans;

}


int judge(){
    std::string j;std::cin>>j;
    if(j=="yes"||j=="y"||j=="Yes"||j=="Y"||j=="YES"){
        return 1;
    }
    else{
        return 0;
    }


}
double calcu(Poly_member* h1){
    double x;std::cin>>x;
    return calculate_Poly(h1, x);
}


Poly_member* D[10000];
void poly_calculator(){
    hello_calculator();

    while(1){
        int point_n=1,Point_w;
        int flagg=0;
        std::cout<<"Enter the first polynomial:"<<std::endl;
        Poly_member* A;
        A=init_Poly_member();
        std::cout<<"A=";
        show_Poly(A);
        std::cout<<std::endl;
        std::cout<<"Select the calculation method (1 represents addition operation, 2 represents subtraction operation):"<<std::endl;
        int mode;
        while(1){
            std::cin>>mode;
            if(mode!=1&&mode!=2){
                std::cout<<"Illegal input, please select the calculation method again."<<std::endl;
            }
            else{
                break;
            }
        }
        std::cout<<"Enter the second polynomial:"<<std::endl;
        Poly_member* B;
        B=init_Poly_member();
        std::cout<<"B=";
        show_Poly(B);
        std::cout<<std::endl;
        std::cout<<"Below are the calculation results:"<<std::endl;
        Poly_member* C;
        if(mode==1){
            C=Poly_plus(A, B);
        }
        if(mode==2){
            C=Poly_subtraction(A, B);
        }
        std::cout<<"C=";
        show_Poly(C);
        std::cout<<std::endl;
        std::cout<<"Do you need to calculate the value of the polynomial at x [yes/no]:";
        int flag1=judge();
        if(flag1==1){
            std::cout<<"Please enter the value of x:";
            double ans=calcu(C);
            std::cout<<"The result is:"<<std::setprecision(5)<<ans<<std::endl;
        }
        std::cout<<"Do you need to exit the program now [yes/no]:";
        int flag2=judge();
        if(flag2==1){
            break;
        }
        std::cout<<"Is there any other requirement?"<<std::endl;
        std::cout<<"1. Calculate the value of polynomial A at a certain point."<<std::endl;
        std::cout<<"2. Calculate the value of polynomial B at a certain point."<<std::endl;
        std::cout<<"3. Modify the expression of polynomial A."<<std::endl;
        std::cout<<"4. Modify the expression of polynomial B."<<std::endl;
        std::cout<<"5. Recalculate the expression of C."<<std::endl;
        std::cout<<"6. Display the current expressions of A, B, and C."<<std::endl;
        std::cout<<"7. 7. Calculate the value of polynomial C at a certain point."<<std::endl;
        std::cout<<"8. End the program."<<std::endl;
        std::cout<<"9. Continue to add polynomials and perform calculations."<<std::endl;

        while(1){
            std::cout<<"Please enter a command:";
            std::cin>>mode;
            if(mode==1){
                std::cout<<"Please enter the value of x:";
                double ans=calcu(A);
                std::cout<<"The result for A is:"<<std::setprecision(5)<<ans<<std::endl;
            }
            if(mode==2){
                std::cout<<"Please enter the value of x:";
                double ans=calcu(B);
                std::cout<<"The result for B is:"<<std::setprecision(5)<<ans<<std::endl;
            }
            if(mode==3){
                std::cout<<"Please enter the expression for A:";
                A=init_Poly_member();
                std::cout<<"A=";
                show_Poly(A);
                std::cout<<std::endl;
            }
            if(mode==4){
                std::cout<<"Please enter the expression for B:";
                B=init_Poly_member();
                std::cout<<"B=";
                show_Poly(B);
                std::cout<<std::endl;
            }
            if(mode==5){

                std::cout<<"Please enter the calculation method (1 for addition, 2 for subtraction):";
                int mode;
                while(1){
                    std::cin>>mode;
                    if(mode!=1&&mode!=2){
                        std::cout<<"Illegal input, please choose the calculation method again."<<std::endl;
                    }
                    else{
                        break;
                    }
                }

                if(mode==1){
                    C=Poly_plus(A, B);
                }
                if(mode==2){
                    C=Poly_subtraction(A, B);
                }
                std::cout<<"The expression for C is:";
                show_Poly(C);
                std::cout<<std::endl;

            }
            if(mode==6){
                std::cout<<"A=";
                show_Poly(A);
                std::cout<<std::endl;
                std::cout<<"B=";
                show_Poly(B);
                std::cout<<std::endl;
                std::cout<<"C=";
                show_Poly(C);
                std::cout<<std::endl;

            }
            if(mode==7){
                std::cout<<"Please enter the value of x:";
                double ans=calcu(C);
                std::cout<<"The result for C is:"<<std::setprecision(5)<<ans<<std::endl;

            }
            if(mode==8){
                flagg=1;
                break;
            }
            if(mode==9){
                A=C;
                std::cout<<"Please enter the calculation method (1 for addition, 2 for subtraction):";
                int mode;
                while(1){
                    std::cin>>mode;
                    if(mode!=1&&mode!=2){
                        std::cout<<"Illegal input, please reselect the calculation method."<<std::endl;
                    }
                    else{
                        break;
                    }
                }
                std::cout<<"Please enter the additional polynomial to be added (it will be stored in D["<<point_n<<"]):"<<std::endl;
                D[point_n]=init_Poly_member();
                std::cout<<"D["<<point_n<<"]=";
                show_Poly(D[point_n]);
                std::cout<<std::endl;

                if(mode==1){
                    C=Poly_plus(C, D[point_n++]);
                    std::cout<<"answer(C)=";
                    show_Poly(C);
                }
                if(mode==2){
                    C=Poly_subtraction(C, D[point_n++]);
                }

                

            }
            std::cout<<std::endl;
            std::cout<<"Do you need to exit the program now [yes/no]:";
            int flag2=judge();
            if(flag2==1){
                flagg=1;
                break;
            }


        }
        if(flagg==1){
            break;
        }

        
    }
}
int main(){
    poly_calculator();
    return 0;
}
