#include<bits/stdc++.h>

void hello_calculator(){
    std::cout<<"这是一个一元稀疏多项式计算器。"<<std::endl;
    std::cout<<"以下是使用说明。"<<std::endl;
    std::cout<<"在输入多项式时，按如下格式输入："<<std::endl;
    std::cout<<std::endl;
    std::cout<<"先输入多项式的项数，之后按指数降序的顺序依次输入每项的系数和指数。连续输入两个负数将会结束输入。"<<std::endl;
    std::cout<<std::endl;
    std::cout<<"选择计算方式，1代表加法运算，2代表减法运算。"<<std::endl;
    std::cout<<std::endl;
    std::cout<<"确定是否要计算多项式在x处的值[yes/no]"<<std::endl;
    std::cout<<std::endl;
    std::cout<<"如要计算多项式在x处的值，请输入x的值。"<<std::endl;

}
/*
class Poly_member;
Poly_member* Poly_plus(Poly_member* h1,Poly_member* h2);
*/
class Poly_member{
private:
    double exponent;
    double coefficient;
    Poly_member* next;
public:
    friend Poly_member* Poly_plus(Poly_member* h1,Poly_member* h2);
    friend Poly_member* Poly_subtraction(Poly_member* h1,Poly_member* h2);
    friend Poly_member* init_Poly_member();
    friend double calculate_Poly(Poly_member* h1,double x);
    friend void show_Poly(Poly_member* he);     
};

void show_Poly(Poly_member* he){
    Poly_member* temp=he->next;
        int flag=1;
        while(1){
            if(temp==NULL){
                break;
            }
            if(temp->coefficient==0){
                temp=temp->next;
                continue;
            }
            if(flag==1){
                flag=0;
            }
            else{
                std::cout<<"+";
            }
            
            if(temp->coefficient>=0){
                std::cout<<temp->coefficient<<"x^"<<temp->exponent;
            }
            else{
                std::cout<<"("<<temp->coefficient<<"x^"<<temp->exponent<<")";
            }
            temp=temp->next;
        }
        if(flag==1){
            std::cout<<"0"<<std::endl;
        }
}



Poly_member* Poly_plus(Poly_member* h1,Poly_member* h2){
    Poly_member* t1=h1->next;
    Poly_member* t2=h2->next;
    Poly_member* sum=new Poly_member();
    sum->next=NULL;
    Poly_member* temp=sum;
    while(1){
        if(t1==NULL&&t2==NULL){
            break;
        }
        if(t1!=NULL&&t2!=NULL){
            if(t1->exponent>t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t1->exponent;
                a->coefficient=t1->coefficient;
                temp->next=a;
                temp=temp->next;
                t1=t1->next;
                continue;
            }
            if(t1->exponent<t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t2->exponent;
                a->coefficient=t2->coefficient;
                temp->next=a;
                temp=temp->next;
                t2=t2->next;
                continue;
            }
            if(t1->exponent==t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t1->exponent;
                a->coefficient=t1->coefficient+t2->coefficient;
                temp->next=a;
                temp=temp->next;
                t1=t1->next;
                t2=t2->next;
                continue;
            }
        }
        if(t1==NULL&&t2!=NULL){
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=t2->exponent;
            a->coefficient=t2->coefficient;
            temp->next=a;
            temp=temp->next;
            t2=t2->next;
            continue;
        }
        if(t1!=NULL&&t2==NULL){
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=t1->exponent;
            a->coefficient=t1->coefficient;
            temp->next=a;
            temp=temp->next;
            t1=t1->next;
            continue;
        } 
        
        
    }
    return sum;
}
Poly_member* Poly_subtraction(Poly_member* h1,Poly_member* h2){
    Poly_member* t1=h1;
    Poly_member* t2=h2;
    Poly_member* ans=new Poly_member();
    ans->next=NULL;
    Poly_member* temp=ans;
    while(1){
        if(t1==NULL&&t2==NULL){
            break;
        }
        if(t1!=NULL&&t2!=NULL){
            if(t1->exponent>t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t1->exponent;
                a->coefficient=t1->coefficient;
                temp->next=a;
                temp=temp->next;
                t1=t1->next;
                continue;

            }
            if(t1->exponent<t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t2->exponent;
                a->coefficient=-t2->coefficient;
                temp->next=a;
                temp=temp->next;
                t2=t2->next;
                continue;
            }
            if(t1->exponent==t2->exponent){
                Poly_member* a=new Poly_member();
                a->next=NULL;
                a->exponent=t1->exponent;
                a->coefficient=t1->coefficient-t2->coefficient;
                temp->next=a;
                temp=temp->next;
                t1=t1->next;
                t2=t2->next;
                continue;
            }
        }
        if(t1==NULL&&t2!=NULL){
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=t2->exponent;
            a->coefficient=-t2->coefficient;
            temp->next=a;
            temp=temp->next;
            t2=t2->next;
            continue;
        }
        if(t1!=NULL&&t2==NULL){
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=t1->exponent;
            a->coefficient=t1->coefficient;
            temp->next=a;
            temp=temp->next;
            t1=t1->next;
            continue;
        }
    }
    return ans->next;
}








Poly_member* init_Poly_member(){
        Poly_member* head=new Poly_member();
        head->next=NULL;
        Poly_member* temp=head;
        int n;std::cin>>n;
        int i=0;
        while(i<n){
            double exp,coe;std::cin>>coe>>exp;
            if(coe<0&&exp<0){
                break;
            }
            Poly_member* a=new Poly_member();
            a->next=NULL;
            a->exponent=exp;
            a->coefficient=coe;
            temp->next=a;
            temp=temp->next;
            i++;
        }
        return head;
}

double calculate_Poly(Poly_member* h1,double x){
    double ans=0.0;
    Poly_member* temp=h1->next;
    while(1){
        if(temp==NULL){
            break;
        }
        else{
            ans=ans+(temp->coefficient*pow(x,temp->exponent));
            temp=temp->next;
        }
    }
    return ans;

}


int judge(){
    std::string j;std::cin>>j;
    if(j=="yes"||j=="y"||j=="Yes"||j=="Y"||j=="YES"){
        return 1;
    }
    else{
        return 0;
    }


}
double calcu(Poly_member* h1){
    double x;std::cin>>x;
    return calculate_Poly(h1, x);
}


Poly_member* D[10000];
void poly_calculator(){
    hello_calculator();

    while(1){
        int point_n=1,Point_w;
        int flagg=0;
        std::cout<<"输入第一个多项式："<<std::endl;
        Poly_member* A;
        A=init_Poly_member();
        std::cout<<"A=";
        show_Poly(A);
        std::cout<<std::endl;
        std::cout<<"选择计算方式（1代表加法运算，2代表减法运算）："<<std::endl;
        int mode;
        while(1){
            std::cin>>mode;
            if(mode!=1&&mode!=2){
                std::cout<<"非法输入，请请重新选择计算方式。"<<std::endl;
            }
            else{
                break;
            }
        }
        std::cout<<"输入第二个多项式："<<std::endl;
        Poly_member* B;
        B=init_Poly_member();
        std::cout<<"B=";
        show_Poly(B);
        std::cout<<std::endl;
        std::cout<<"以下是计算结果："<<std::endl;
        Poly_member* C;
        if(mode==1){
            C=Poly_plus(A, B);
        }
        if(mode==2){
            C=Poly_subtraction(A, B);
        }
        std::cout<<"C=";
        show_Poly(C);
        std::cout<<std::endl;
        std::cout<<"需要计算多项式在x处的值嘛[yes/no]:";
        int flag1=judge();
        if(flag1==1){
            std::cout<<"请输入x的值:";
            double ans=calcu(C);
            std::cout<<"结果为:"<<std::setprecision(5)<<ans<<std::endl;
        }
        std::cout<<"现在需要退出程序嘛[yes/no]:";
        int flag2=judge();
        if(flag2==1){
            break;
        }
        std::cout<<"是否还有其他需求?"<<std::endl;
        std::cout<<"1. 计算A多项式在某处的值"<<std::endl;
        std::cout<<"2. 计算B多项式在某处的值"<<std::endl;
        std::cout<<"3. 修改A的表达式"<<std::endl;
        std::cout<<"4. 修改B的表达式"<<std::endl;
        std::cout<<"5. 重新计算C的表达式"<<std::endl;
        std::cout<<"6. 显示当前A，B，C的表达式"<<std::endl;
        std::cout<<"7. 计算C多项式在某处的值"<<std::endl;
        std::cout<<"8. 结束程序"<<std::endl;
        std::cout<<"9. 继续添加多项式并计算"<<std::endl;

        while(1){
            std::cout<<"请输入指令：";
            std::cin>>mode;
            if(mode==1){
                std::cout<<"请输入x的值:";
                double ans=calcu(A);
                std::cout<<"A的结果为:"<<std::setprecision(5)<<ans<<std::endl;
            }
            if(mode==2){
                std::cout<<"请输入x的值:";
                double ans=calcu(B);
                std::cout<<"B的结果为:"<<std::setprecision(5)<<ans<<std::endl;
            }
            if(mode==3){
                std::cout<<"请输入A的表达式：";
                A=init_Poly_member();
                std::cout<<"A=";
                show_Poly(A);
                std::cout<<std::endl;
            }
            if(mode==4){
                std::cout<<"请输入B的表达式：";
                B=init_Poly_member();
                std::cout<<"B=";
                show_Poly(B);
                std::cout<<std::endl;
            }
            if(mode==5){

                std::cout<<"请输入计算方式（1为加法，2为减法）:";
                int mode;
                while(1){
                    std::cin>>mode;
                    if(mode!=1&&mode!=2){
                        std::cout<<"非法输入，请重新选择计算方式。"<<std::endl;
                    }
                    else{
                        break;
                    }
                }

                if(mode==1){
                    C=Poly_plus(A, B);
                }
                if(mode==2){
                    C=Poly_subtraction(A, B);
                }
                std::cout<<"C的表达式为:";
                show_Poly(C);
                std::cout<<std::endl;

            }
            if(mode==6){
                std::cout<<"A=";
                show_Poly(A);
                std::cout<<std::endl;
                std::cout<<"B=";
                show_Poly(B);
                std::cout<<std::endl;
                std::cout<<"C=";
                show_Poly(C);
                std::cout<<std::endl;

            }
            if(mode==7){
                std::cout<<"请输入x的值:";
                double ans=calcu(C);
                std::cout<<"C的结果为:"<<std::setprecision(5)<<ans<<std::endl;

            }
            if(mode==8){
                flagg=1;
                break;
            }
            if(mode==9){
                A=C;
                std::cout<<"请输入计算方式（1为加法，2为减法）:";
                int mode;
                while(1){
                    std::cin>>mode;
                    if(mode!=1&&mode!=2){
                        std::cout<<"非法输入，请重新选择计算方式。"<<std::endl;
                    }
                    else{
                        break;
                    }
                }
                std::cout<<"请输入继续添加的多项式（会存储于D["<<point_n<<"]):"<<std::endl;
                D[point_n]=init_Poly_member();
                std::cout<<"D["<<point_n<<"]=";
                show_Poly(D[point_n]);
                std::cout<<std::endl;

                if(mode==1){
                    C=Poly_plus(C, D[point_n++]);
                    std::cout<<"answer(C)=";
                    show_Poly(C);
                }
                if(mode==2){
                    C=Poly_subtraction(C, D[point_n++]);
                }

                

            }
            std::cout<<std::endl;
            std::cout<<"现在需要退出程序嘛[yes/no]:";
            int flag2=judge();
            if(flag2==1){
                flagg=1;
                break;
            }


        }
        if(flagg==1){
            break;
        }

        
    }
}
int main(){
    poly_calculator();
    return 0;
}
